"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const axios_1 = __importDefault(require("axios"));
const console_1 = require("console");
const handler = async (payload) => {
    const apiKey = process.env.API_KEY;
    const apiUrl = process.env.API_URL;
    const { headers, data } = payload;
    headers.Authorization = headers.Authorization + apiKey;
    try {
        if (!apiUrl) {
            throw new console_1.error('API URL is missing');
        }
        const response = await axios_1.default.post(apiUrl, JSON.stringify(data), {
            headers: headers,
        });
        if (response.status >= 200 && response.status <= 206) {
            console.log(`Resquest sent to API successfully with status ${response.status}`);
        }
        else {
            console.error(`Failed to send resquest to API. Status code: ${response.status}, Response: ${response.data}`);
        }
    }
    catch (error) {
        console.error('Error sending resquest to API:', error.message);
    }
};
exports.handler = handler;
