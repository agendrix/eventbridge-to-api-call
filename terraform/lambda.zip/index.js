"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const axios_1 = __importDefault(require("axios"));
const console_1 = require("console");
const handler = async (payload) => {
    const apiKey = process.env.API_KEY;
    const apiUrl = process.env.API_URL;
    const { headers, data } = payload;
    headers.Authorization = headers.Authorization + apiKey;
    try {
        if (!apiUrl) {
            throw console_1.error;
        }
        // Make the HTTP request using Axios
        const response = await axios_1.default.post(apiUrl, data, {
            headers: headers,
        });
        if (response.status === 200) {
            console.log('Alert sent to API successfully');
        }
        else {
            console.error(`Failed to send alert to API. Status code: ${response.status}, Response: ${response.data}`);
        }
    }
    catch (error) {
        console.error('Error sending alert to API:', error.message);
    }
};
exports.handler = handler;
